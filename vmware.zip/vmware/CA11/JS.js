

function validate()
{
   var num = /^(?:[0-9]{4}1[A-Za-z]{3}[0-9]{4})$/;
   if(document.Registration.uid.value==""||!num.test(document.Registration.uid.value))
   {
      alert("Please provide your valid uid!");
	  document.Registration.uid.focus();
	  return false;
	  
	}
	
	var letter = /^(?:[A-Za-z/s])+$/;
     if(document.Registration.name.value==""||!letter.test(document.Registration.name.value))
   {
      alert("Please provide your valid name !");
	  document.Registration.name.focus();
	  return false;
	  
	}
	
	var letter1 = /^(?:[0-9]{2})+$/;
     if(document.Registration.km.value==""||!letter1.test(document.Registration.km.value))
   {
      alert("Please provide your valid distance !");
	  document.Registration.km.focus();
	  return false;
	  
	}
}