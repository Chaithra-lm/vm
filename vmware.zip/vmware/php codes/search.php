<?php

$con=mysqli_connect("localhost","root","","student1");

$query="select * from student_info1";
$sql=mysqli_query($con,$query)
or
die("Error querying the database");
echo "<br/>";
echo"fetching success";
echo "<br/>";
echo "<table border=1>";
echo "<tr><th>name</th>";
echo "<th>rno</th>";
echo "<th>mail</th></tr>";
while($row = mysqli_fetch_array($sql,MYSQLI_ASSOC)) 
{
	echo "<td>".$row['name']."</td>";
	echo "<td>".$row['rno']."</td>";
	echo "<td>".$row['mail']."</td></tr>"; 
}



?>