
<!DOCTYPE html>
<html>
<body bgcolor="pink">

<h1>My first PHP page</h1>

<?php
echo "Hello World!";
?>

<?php

define("MINSIZE",50);
echo MINSIZE;
echo "<br>";
echo constant("MINSIZE");
echo "<br>";
echo "<br>";


$x=3;
$y=43;




echo "Addition of two numbers : ",$x+$y;
echo "<br>";
echo "subtraction of two numbers : ",$x-$y;
echo "<br>";
echo "multiplication of two numbers : ",$x*$y;
echo "<br>";
echo "division of two numbers : ",$x/$y;
echo "<br>";
echo "Reminder of two numbers : ",$x%$y;
echo "<br>";



echo "<br>";
echo "<br>";
printf("division of two numbers :%d",$x/$y);

echo "<br>";
echo "<br>";
printf("division of two numbers :%.2f",$x/$y);
printf("<br>");
printf("division of two numbers :%.2f",$x/$y);

echo "<br>";
echo "<br>";

$d=date("D");

if($d=="Fri")
{
	echo "Have a nice weekend";
}
elseif ($d=="Sun")
{
	echo "have a nice day";
}
else
{
	echo "have a wonderful weekdays";
}

echo "<br><br>";
echo date("l") . "<br>";

// Prints the day, date, month, year, time, AM or PM
echo date("l jS \of F Y h:i:s A") . "<br>";

// Prints October 3, 1975 was on a Friday
echo "Oct 3,1975 was on a ".date("l", mktime(0,0,0,10,3,1975)) . "<br>";

// Use a constant in the format parameter
echo date(DATE_RFC822) . "<br>";

// prints something like: 1975-10-03T00:00:00+00:00
echo date(DATE_ATOM,mktime(0,0,0,10,3,1975));


echo "<br>";
echo "<br>";

$a=5;
$b=10;


$array=array(10,20,30,40,50);
$ar=[1,2,3,0,4,5,6];
foreach($ar as $value)
{
	echo "the value is $value <br>";
	echo "<br>";

}

for($i=0;$i<5;$i++)
{
	$a+=5;
	$b+=10;
}
echo "<br>";
echo "The value of $a and $b";
echo "<br>";

$array=array(1,2,3,4,5);
echo "<br>";
for($i=0;$i<sizeof($array);$i++)
{
	echo $array[$i];
	echo "<br>";
}

echo "<br>";
echo "<br>";
$salaries = array("James" => 1000, "Shweta" => 1500, "Sunil" => 2000);
echo "Salary of james is ".$salaries['James'];
	
echo "<br>";
echo "<br>";

$string1="Hello World";
$string2="1234";
echo $string1 . "" . $string2;

echo "<br>";
echo "<br>";


?> 



<form method="css";>
First number : <input type="text" name = "first"><br><br>
second number : <input type="text" name = "second"><br><br>
<input type="submit" value="add" name="submit1">
<input type="submit" value="sub" name="submit2">
<input type="submit" value="mul" name="submit3">
<input type="submit" value="div" name="submit4">
</form>

<?php  

if(isset($_GET['submit1']))
{
	$n1 = $_GET['first'];
	
	$n2= $_GET['second'];
	
	if(gettype($value)=='numeric' && gettype('numeric')=='numeric')
	{
	$sum = $n1 + $n2;
	
	echo "sum of $n1 & $n2 is ".$sum."<br>";
	}
	else
	{
	  echo "<script type='text/javascript' > alert('enter valid number');</script>";
	}
}

elseif(isset($_GET['submit2']))
{

	$n1 = $_GET['first'];
	$n2= $_GET['second'];
	$subtract = $n1 - $n2;
	
	echo "subtract of $n1 & $n2 is ".$subtract."<br>";

}

elseif(isset($_GET['submit3']))
{

	$n1 = $_GET['first'];
	$n2= $_GET['second'];
	$product = $n1 * $n2;
	
	echo "product of $n1 & $n2 is ".$product."<br>";

}
elseif(isset($_GET['submit4']))
{

	$n1 = $_GET['first'];
	$n2= $_GET['second'];
	$division = $n1 / $n2;
	
	echo "division of $n1 & $n2 is ".$division."<br>";

}

echo "<br>";
echo "<br>";

?>



<form action = "<?php $_PHP_SELF ?>" method = "GET">
Name: <input type = "text" name = "name" />
Age: <input type = "text" name = "age" />
<input type = "submit" />
</form>

<?php
echo "<br>";
echo "<br>";
if( $_GET["name"] || $_GET["age"] ) {
echo "Welcome ". $_GET['name']. "<br />";
echo "You are ". $_GET['age']. " years old.";
echo "<br>";
echo "<br>";
}
?>



<form action = "<?php $_PHP_SELF ?>" method = "POST">
Name: <input type = "text" name = "name" />
Age: <input type = "text" name = "age" />
<input type = "submit" />
</form>

<?php
echo "<br>";
echo "<br>";
if( $_REQUEST["name"] || $_REQUEST["age"] ) {
echo "Welcome ". $_REQUEST['name']. "<br />";
echo "You are ". $_REQUEST['age']. " years old.";
echo "<br>";
echo "<br>";
}

include("static.php");
?>




</body>
</html>