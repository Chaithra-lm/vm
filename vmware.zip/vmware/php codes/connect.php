
<html>
<head>
<title> PHP </title>

</head>
<body>

<?php
$host='localhost';
$user='root';
$pwd='';
$db='student';

$connect = mysqli_connect($host,$user,$pwd,$db)
or
die("Error connecting the database");
echo"connection is success";

?>

</body>
</html>