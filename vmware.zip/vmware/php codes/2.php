<html>
<head>
<title> PHP </title>

</head>
<body>

<?php

include("connect.php");
$query = "select * from student";
$result = mysqli_query($connect,$query) 
or 
die("Error querying the database");

echo "<br/>";

echo"fetching success"; 

echo "<br/>";
echo "<br/>";

while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
{
echo "NAME: " . $row['name']."<br/>";
echo "ID: " . $row['id']."<br/>";
echo "age " . $row['age']."<br/>";
echo "gender: " . $row['gender']."<br/>";
echo "<br/> <br/>";
} 


echo "<table border=1>";
echo "<tr><th>id</th>";
echo "<th>name</th>";
echo "<th>age</th>";
echo "<th>gender</th></tr>";

$query1 = "select * from student";
$result1 = mysqli_query($connect,$query1); 

while($row = mysqli_fetch_array($result1,MYSQLI_ASSOC)) 
{
	echo "<tr><td>".$row['id']."</td>";
	echo "<td>".$row['name']."</td>";
	echo "<td>".$row['age']."</td>";
	echo "<td>".$row['gender']."</td></tr>";

}


?>

</body>
</html>