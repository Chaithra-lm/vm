<html>
<head>
<style>
div {
	align:left;
	width:45%;
	height:700px;
    border: solid black;
    background-color:orange;
    margin-left:400px;
	margin-top:0px;
    padding: 20px;
}
 
</style>
</head>
<body>


<div>
<h1>Enter data for Student</h1>

<form  method="post">
Name:<br />
<input type="text" size="40" name="name"/><br /><br/>
Roll number:<br />
<input type="text" size="40" name="rno"/><br/><br/>
Official mail id:<br />
<input type="text" size="40" name="mail"/><br /><br/>
<br><br>

<table>
<td><input type="submit" value="Submit" name="OK"/></td>
<td><input type="reset" name="reset" value="reset"/></td></table>
</form>


<?php  
$con=mysqli_connect("localhost","root","","student1");
if(isset($_POST['OK'])){
$p =$_POST['name'];
$f =$_POST['rno']; 
$w=$_POST['mail']; 
$sql=mysqli_query($con,"INSERT INTO student_info1 (name,rno,mail) VALUES ('$p','$f','$w')");
}
?>

<form action='search.php' method='post' target='_blank'>
<table>
              <table border=2 bgcolor=lightblue align=center>
              <tr>
	           <td>Enter name to search</td>
	               <td><input type="text" name="txtname1"/></td>
                    </tr>
	       <tr>
                           <td><input type="submit" value="Search" name="OK"/></td>
                           <td><input type="reset" name="reset" value="reset"/></td>
           </tr>
</table>
</form>



<?php  
$con=mysqli_connect("localhost","root","","student1");
if(isset($_POST['OK'])){ 
$q = $_POST['txtname1'];
$sql=mysqli_query($con,"delete from student_info1 where name = '$q';");
}
?>

<form method='post'>
<table>
              <table border=2 bgcolor=lightblue align=center>
              <tr>
	           <td>Enter name to delete</td>
	               <td><input type="text" name="txtname1"/></td>
                    </tr>
	       <tr>
                           <td><input type="submit" value="Delete" name="OK"/></td>
                           <td><input type="reset" name="reset" value="reset"/></td>
           </tr>
</table>
</form>
<script type="text/javascript">alert("Table row is deleted");</script>

<?php  
$con=mysqli_connect("localhost","root","","student1");
if(isset($_POST['OK1'])){ 
$a = $_POST['txtname2'];
$sql=mysqli_query($con,"update student_info1 set name='$a' where name = 'rno' ");
}
?>

<form method='post'>
<table>
              <table border=2 bgcolor=lightblue align=center>
              <tr>
	           <td>Enter name to update</td>
	               <td><input type="text" name="txtname2"/></td>
                    </tr>
	       <tr>
                           <td><input type="submit" value="Update" name="OK1"/></td>
                           <td><input type="reset" name="reset" value="reset"/></td>
           </tr>
		   
		   
</table>
</form>
<script type="text/javascript">alert("Table is updated");</script>



</div>
</body>
</html>