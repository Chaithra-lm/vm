<html>
<head>
<title> PHP </title>

</head>
<body>

<?php

/*$host = 'localhost';
$user='root';
$pwd='';

$connect = mysqli_connect($host,$user,$pwd) 
or
die("connection failed");

echo "connection is successful";


$db_create = "CREATE DATABASE employee1";

$result = mysqli_query($connect,$db_create)
or
die("Database is not created");
echo "<br>";
echo "Database is created successfully";  

$result = "CREATE TABLE emp_info( id  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name varchar not null, age varchar not null, gender char(1) not null)";

$result = mysqli_query($db_create,$result)
or
die("table is not created");
echo "<br>";
echo "table is created successfully"; */


include("connect.php");

$update = "UPDATE student SET name = 'Arjun' where name = 'aman' ";
$result = mysqli_query($connect,$update)
or
die("update is not done");
echo "<br>";
echo "upadte is done successfully";  







?>

</body>
</html>