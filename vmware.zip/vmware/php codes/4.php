<html>
<head>
<title> PHP </title>

</head>
<body>

<?php
$db_host='localhost';
$db_user='root';
$db_passwd='';
$db='student';


$conf = mysqli_connect($db_host,$db_user,$db_passwd,$db) 
or 
die("Error connecting to the database");
echo"connection is success";//not required only for first time use

 

$crttb="CREATE TABLE student(id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(20) NOT NULL,
age INT(6) NOT NULL,
gender CHAR(1) NOT NULL)";

 
$result1 = mysqli_query($conf,$crttb)
or
die("Error querying the database");
echo "<br/>";
echo"Table is created successfully"; 


$ins = "INSERT INTO student (id,name,age,gender) VALUES(86,'Chaithra',21,'f')";
$result4 = mysqli_query($conf,$ins)
or
die("Error querying the database");
echo "<br/>";
echo"data is inserted successfully";



$ins = "INSERT INTO student (id,name,age,gender) VALUES(13,'aman',21,'m')";
$result4 = mysqli_query($conf,$ins)
or
die("Error querying the database");
echo "<br/>";
echo"data is inserted successfully"; 


$query = "select * from student where gender='f'"; // user_info is a table from Demo database
$result = mysqli_query($conf,$query) or 
die("Error querying the database");
echo "<br/>";
echo"fetching success"; // not required only for initial code
echo "<br/>";
echo "<table border=1>";
echo "<tr><th>id</th>";
echo "<th>name</th>";
echo "<th>age</th>";
echo "<th>gender</th></tr>";

while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) //mysqli_fetch_assoc($result);
{
	echo "<tr><td>".$row['id']."</td>";
	echo "<td>".$row['name']."</td>";
	echo "<td>".$row['age']."</td>";
	echo "<td>".$row['gender']."</td></tr>"; 
	
	

}



$query = "DELETE from student WHERE id='13'"; // user_info is a table from Demo database
$result = mysqli_query($conf,$query) or 
die("Error querying the database");
echo "<br/>";
echo"fetching success"; // not required only for initial code
echo "<br/>";

/*




echo "<table border=1>";
echo "<tr><th>id</th>";
echo "<th>name</th>";
echo "<th>age</th>";
echo "<th>gender</th></tr>";
while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) //mysqli_fetch_assoc($result);
{
	echo "<tr><td>".$row['id']."</td>";
	echo "<td>".$row['name']."</td>";
	echo "<td>".$row['age']."</td>";
echo "<td>".$row['gender']."</td></tr>"; }*/


?>


</body>
</html>