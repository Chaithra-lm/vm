<?php
$host='localhost';
$user_name='root';
$passwd='root@123';
$dbname="student1";
$con= mysqli_connect($host,$user_name,$passwd,$dbname);

if(isset($_POST['submit']))
{
	$name=$_POST['txtname'];
	$add1=$_POST['txtaddr1'];
	$add2=$_POST['txtaddr2'];
	$email=$_POST['txtemail'];
 $s="insert into person values('$name','$add1','$add2','$email')";	
$result=mysqli_query($con,$s);
if($result)
echo"<h1>inserted successfully</h1>";
else
echo "<h1>insertion failed</h1>";
}
else if(isset($_POST['search']))
{
	$name1=$_POST['txtname1'];
	$s1="select * from person where name='$name1'";
	$result = mysqli_query($con,$s1) or
die("Error querying the database");
echo "<br/>";

echo"fetching success"; // not required only for initial code
echo "<br/>";
echo "<table border=1>";
echo "<tr><th>name</th>";
	echo "<th>add1</th>";
	echo "<th>add2</th>";
	echo "<th>email</th></tr>";
while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) //mysqli_fetch_assoc($result);
{
	echo"<tr><td>".$row['name']."</td>";
	echo"<td>".$row['addr1']."</td>";
	echo"<td>".$row['addr2']."</td>";
	echo"<td>".$row['email']."</td></tr>";
}
}
?>