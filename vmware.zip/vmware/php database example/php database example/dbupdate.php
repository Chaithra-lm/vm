<html>
<body bgcolor="pink">
<h1>
<?php
$host='localhost';
$user_name='root';
$passwd='root@123';
$name="demo";
$con= mysqli_connect($host,$user_name,$passwd,$name)
or
die("Error connecting to the database");
echo"connection is success";

$uptb = "update emp_info3 set age='40' where id=3";
$result = mysqli_query($con,$uptb) or
die("Error quering the database");


echo "</br>"."data updated successfully";
?>
</h2>
</body>
</html>
