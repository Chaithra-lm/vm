<html>
<body bgcolor="pink">
<h1>
<?php
$host='localhost';
$user_name='root';
$passwd='root@123';
$name="demo1";
$con= mysqli_connect($host,$user_name,$passwd,$name)
or
die("Error connecting to the database");
echo"connection is success";

$crttb = "CREATE TABLE emp_info(
id INT(6) PRIMARY KEY,
name VARCHAR(20),
age INT(6) NOT NULL,
gender CHAR(1) NOT NULL)";
$result = mysqli_query($con,$crttb) or
die("Error quering the database");

echo "<br/>"."table created successfully";
?>
</h2>
</body>
</html>