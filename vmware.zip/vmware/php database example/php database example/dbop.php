<html>
<body bgcolor="pink">
<h1>
<?php
$host='localhost';
$username='root';
$password='root@123';


$con= mysqli_connect($host,$username,$password)
or
die("Error connecting to the database");
echo"connection is success";//not required only for first time use

$crtdb="CREATE DATABASE demo1";
$result=mysqli_query($con,$crtdb)or 
die("Error querying to the database");
echo "<br>";
echo"database created successfully";
?>
</h2>
</body>
</html>