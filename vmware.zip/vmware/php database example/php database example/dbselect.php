<html>
<body bgcolor="pink">
<h1>
<?php
$host='localhost';
$user_name='root';
$passwd='root@123';
$name="demo1";
$con= mysqli_connect($host,$user_name,$passwd,$name)
or
die("Error connecting to the database");
echo"connection is success";

$query = "select * from emp_info"; // user_infois a table from Demo database
$result = mysqli_query($con,$query) or
die("Error querying the database");
echo "<br/>";

echo"fetching success"; // not required only for initial code
echo "<br/>";
echo "<table border=1>";
echo "<tr><th>ID</th>";
	echo "<th>Name</th>";
	echo "<th>age</th>";
	echo "<th>gender</th></tr>";
while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) //mysqli_fetch_assoc($result);
{
	echo"<tr><td>".$row['id']."</td>";
	echo"<td>".$row['name']."</td>";
	echo"<td>".$row['age']."</td>";
	echo"<td>".$row['gender']."</td></tr>";
}
?>
</h2>
</body>
</html>