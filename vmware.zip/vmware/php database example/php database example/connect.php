<html>
<body bgcolor="pink">
<h1>
<?php
$db_host='localhost';
$db_user='root';
$db_passwd='root@123';
$db_name="demo";//Give the name as per your DB
$dbh= mysqli_connect($db_host,$db_user,$db_passwd, $db_name)
or
die("Error connecting to the database");
echo"connection is success";//not required only for first time use
?>
</h2>
</body>
</html>