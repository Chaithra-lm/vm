<?php 
  
// Function used for assigning new value to  
// $string variable and printing it 
function print_string( &$string ) { 
      
    $string = "welcome to presidency \n"; 
  
    // Print $string variable 
    print( $string ); 
} 
  
// Driver code 
$string = "dept of CSE \n"; 
print ($string);
print_string( $string ); 
echo "</br>";
print( $string ); 
?>