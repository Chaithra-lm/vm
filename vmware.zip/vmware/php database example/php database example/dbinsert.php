<html>
<body bgcolor="pink">
<h1>
<?php
$host='localhost';
$user_name='root';
$passwd='root@123';
$name="demo1";
$con= mysqli_connect($host,$user_name,$passwd,$name)
or
die("Error connecting to the database");
echo"connection is success";

$ins="INSERT INTO emp_info (id,name,age,gender) VALUES('3','abc','32','M')";

$result=mysqli_query($con,$ins) or 
die("ERROR");
echo "</br>"."data inserted successfully";

$ins1="INSERT INTO emp_info (id,name,age,gender) VALUES('4','abcd','30','M')";

$result=mysqli_query($con,$ins1) or 
die("ERROR");
echo "</br>"."data inserted successfully";
?>
</h2>
</body>
</html>