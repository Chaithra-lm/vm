<tr>
            <td>Distance from University(in km)</td>
            <td><input type=text name=km size="30" style="border:none;border-radius: 20px;box-shadow: 0 5px 18px 0 rgba(0,0,0,0.15),0 6px 15px 0 rgba(0,0,0,0.19);"></td>
          </tr>

          <tr>
            <td>Pick Up Location:</td>
          </tr>

          <tr><td><input type="checkbox" id="Check1" value="Value1" onclick="selectOnlyThis(this.id)">Yelahanka</td>      <td><input type="checkbox" id="Check4" value="Value1" onclick="selectOnlyThis(this.id)">Attur Layout</td></tr>
          <tr><td><input type="checkbox" id="Check2" value="Value1" onclick="selectOnlyThis(this.id)">Hebbal</td>         <td><input type="checkbox" id="Check5" value="Value1" onclick="selectOnlyThis(this.id)">MS Palya</td></tr>
          <tr><td><input type="checkbox" id="Check3" value="Value1" onclick="selectOnlyThis(this.id)">Rajanukunte</td>    <td><input type="checkbox" id="Check6" value="Value1" onclick="selectOnlyThis(this.id)">Jakkur</td></tr>

          <tr>
            <td>Choose AC or Non-AC</td>
            <td><input type="radio" name="cool" value="AC" size="10">AC
                <input type="radio" name="cool" value="Non-AC" size="10">Non-AC</td>
          </tr>

          <tr>
            <td>Present Address</td>
            <td><input type="text" name="address" id="add1" size="30" style="border:none;border-radius: 20px;box-shadow: 0 5px 18px 0 rgba(0,0,0,0.15),0 6px 15px 0 rgba(0,0,0,0.19);"></td>
          </tr>

          <tr>
            <td>Is your current address same as permanent address?</td>
            <td><input type="radio" name="choose" value="Yes" size="10" onclick="Myaddress()">Yes
                <input type="radio" name="choose" value="No" size="10">No</td>
          </tr>

          <tr>
            <td>Present Address(copy)</td>
            <td><input type="text" name="address" id="add3" size="30" style="border:none;border-radius: 20px;box-shadow: 0 5px 18px 0 rgba(0,0,0,0.15),0 6px 15px 0 rgba(0,0,0,0.19);"></td>
          </tr>

          <tr>
            <td>Mobile number</td>
            <td><input type="text" name="mobileno" size="30" style="border:none;border-radius: 20px;box-shadow: 0 5px 18px 0 rgba(0,0,0,0.15),0 6px 15px 0 rgba(0,0,0,0.19);"></td>
          </tr>

          <tr>
            <td>Branch:</td>
            <td><input type="text" name="branch" size="30" style="border:none;border-radius: 20px;box-shadow: 0 5px 18px 0 rgba(0,0,0,0.15),0 6px 15px 0 rgba(0,0,0,0.19);"></td>
          </tr>
