var a = [11,22,33,44,55,66,77,88,99,00];
document.write("Array in descending order"+"<br/>");
a.sort();
a.reverse();
document.write("Length of array ="+a.length+"<br/>");

for (let i = 0; i < a.length; i++)
{
   document.writeln((i+1) + ": " + a[i]+"<br/>");
}

